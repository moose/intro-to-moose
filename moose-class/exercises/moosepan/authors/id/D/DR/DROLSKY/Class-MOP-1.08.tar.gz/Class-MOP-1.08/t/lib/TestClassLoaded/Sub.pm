package TestClassLoaded::Sub;
use strict;
use warnings;

sub ver_test { return "TestClassLoaded ver $TestClassLoaded::VERSION" }

1;

package Role::Parent;
use Moose::Role;

sub meth2  { }
sub meth1 { }

1;

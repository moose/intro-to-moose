package TestClassLoaded;
use strict;
use warnings;

sub a_method { 'a_method' }

1;

